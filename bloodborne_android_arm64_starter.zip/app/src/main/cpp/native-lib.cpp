#include <jni.h>

extern "C"
JNIEXPORT jstring JNICALL
Java_org_bbport_android_MainActivity_nativeStatus(JNIEnv* env, jclass) {
    return env->NewStringUTF(
        "Native ARM64 library loaded successfully. Vulkan/runtime integration pending."
    );
}
