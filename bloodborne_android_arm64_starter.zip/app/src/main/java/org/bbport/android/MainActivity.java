package org.bbport.android;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private static native String nativeStatus();

    static {
        System.loadLibrary("bbport_android");
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        TextView view = new TextView(this);
        view.setBackgroundColor(Color.rgb(18, 18, 22));
        view.setTextColor(Color.WHITE);
        view.setGravity(Gravity.CENTER);
        view.setPadding(32, 32, 32, 32);
        view.setText(
            "Bloodborne Android — CI starter\\n\\n" +
            "ABI: " + android.os.Build.SUPPORTED_ABIS[0] + "\\n\\n" +
            nativeStatus() + "\\n\\n" +
            "This is a packaging/native-build test. The game runtime is not integrated yet."
        );
        setContentView(view);
    }
}
